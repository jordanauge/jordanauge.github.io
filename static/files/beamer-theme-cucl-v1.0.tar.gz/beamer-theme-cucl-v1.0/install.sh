#!/bin/sh

# This file is part of the CUCL beamer template.
# (C) 2008, Jordan Aug� <jordan.auge@cl.cam.ac.uk>
#
# This program is free software: you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later
# version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
# details.
#
# You should have received a copy of the GNU General Public License along with
# this program.  If not, see <http://www.gnu.org/licenses/>.

if [[ $UID != 0 ]]; then
        echo "This program must be run with root privileges to proceed with system-wide"
	echo "installation. The installation will be made locally in your $HOME/texmf"
	echo "directory. Hit Ctrl+C to interrupt..."
	read
	TEXMF="$HOME/texmf"
else
	TEXMF="/usr/share/texmf"
fi

BASE="$TEXMF/tex/latex/beamer/themes/"

mkdir -p $BASE/color
mkdir -p $BASE/font
mkdir -p $BASE/inner
mkdir -p $BASE/outer
mkdir -p $BASE/theme

cp beamercolorthemecucl.sty $BASE/color
cp beamerfontthemecucl.sty $BASE/font
cp beamerinnerthemecucl.sty $BASE/inner
cp beamerouterthemecucl.sty $BASE/outer
cp beamerthemecucl.sty $BASE/theme
cp cucl.eps $BASE/inner
cp cucl.pdf $BASE/inner

if [[ $UID != 0 ]]; then
	ESC_HOME=$(echo $HOME | sed 's/\//\\\//g')
	sed -i "s/\/usr\/share/$ESC_HOME/" $BASE/inner/beamerinnerthemecucl.sty
fi

texhash
