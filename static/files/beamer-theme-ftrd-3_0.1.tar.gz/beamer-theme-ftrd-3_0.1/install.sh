#!/bin/sh

if [[ "$1" == "" && $UID != 0 ]]; then
        echo "This program must be run with root privileges."
        exit;
fi

TEXMF="$1/usr/share/texmf"
BASE="$TEXMF/tex/latex/beamer/themes/"

mkdir -p $BASE/color
mkdir -p $BASE/font
mkdir -p $BASE/inner
mkdir -p $BASE/outer
mkdir -p $BASE/theme

cp beamercolorthemeftrd-3.sty $BASE/color
cp beamerfontthemeftrd-3.sty $BASE/font
cp beamerinnerthemeftrd-3.sty $BASE/inner
cp beamerouterthemeftrd-3.sty $BASE/outer
cp beamerthemeftrd-3.sty $BASE/theme
cp ft.eps $BASE/inner
cp orange.eps $BASE/inner
cp ft.pdf $BASE/inner
cp orange.pdf $BASE/inner
