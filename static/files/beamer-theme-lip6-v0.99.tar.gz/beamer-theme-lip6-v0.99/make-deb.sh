#!/bin/sh

file=beamer-theme-lip6
version=0.99

BASE="debian/usr/share/texmf/tex/latex/beamer/themes/"
mkdir -p $BASE/color
mkdir -p $BASE/font
mkdir -p $BASE/inner
mkdir -p $BASE/outer
mkdir -p $BASE/theme
cp beamercolorthemelip6.sty $BASE/color
cp beamerfontthemelip6.sty $BASE/font
cp beamerinnerthemelip6.sty $BASE/inner
cp beamerouterthemelip6.sty $BASE/outer
cp beamerthemelip6.sty $BASE/theme
cp cnrs.eps $BASE/inner
cp cnrs.pdf $BASE/inner
cp upmc.eps $BASE/inner
cp upmc.pdf $BASE/inner
cp onelab.eps $BASE/inner
cp onelab.pdf $BASE/inner

mkdir -p debian/DEBIAN
find ./debian -type d | xargs chmod 755

cat > debian/DEBIAN/postinst << EOF
#!/bin/sh
texhash
EOF
chmod +x debian/DEBIAN/postinst

cat > debian/DEBIAN/control << EOF
Package: $file
Version: $version
Section: base
Priority: optional
Architecture: all
Depends: 
Maintainer: Jordan Augé <jordan.auge@free.fr>
Description: LIP6 beamer theme
 This packages provides files and logos for creating LaTeX/Beamer
 presentations with the LIP6 template.
EOF

dpkg-deb --build debian >/dev/null
rm debian -Rf
out=$file"_"$version"_all.deb"
mv debian.deb $out
echo $out
