#!/bin/bash

# This file is part of the LIP6 beamer template.
# (C)2011, Jordan Aug� <jordan.auge@lip6.fr>
#
# This program is free software: you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later
# version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
# details.
#
# You should have received a copy of the GNU General Public License along with
# this program.  If not, see <http://www.gnu.org/licenses/>.

if [[ $UID != 0 ]]; then
        echo "This program must be run with root privileges to proceed with system-wide"
	echo "installation. The installation will be made locally in your $HOME/texmf"
	echo "directory. Hit Ctrl+C to interrupt..."
	read
	TEXMF="$HOME/texmf"
else
	TEXMF="/usr/share/texmf"
fi

BASE="$TEXMF/tex/latex/beamer/themes/"

mkdir -p $BASE/color
mkdir -p $BASE/font
mkdir -p $BASE/inner
mkdir -p $BASE/outer
mkdir -p $BASE/theme

cp beamercolorthemelip6.sty $BASE/color
cp beamerfontthemelip6.sty $BASE/font
cp beamerinnerthemelip6.sty $BASE/inner
cp beamerouterthemelip6.sty $BASE/outer
cp beamerthemelip6.sty $BASE/theme
cp cnrs.eps $BASE/inner
cp cnrs.pdf $BASE/inner
cp upmc.eps $BASE/inner
cp upmc.pdf $BASE/inner
cp onelab.eps $BASE/inner
cp onelab.pdf $BASE/inner

if [[ $UID != 0 ]]; then
	ESC_HOME=$(echo $HOME | sed 's/\//\\\//g')
	sed -i "s/\/usr\/share/$ESC_HOME/" $BASE/inner/beamerinnerthemelip6.sty
fi

texhash
